# Glomble App for Android

This is an unnofficial app for the website 'Glomble.com'. It aims to make it easier to use Glomble on Android phones, tablets, and TVs.

It is written in RFO-Basic ([http://www.rfobasic.com/](url)) and compiled with the RFO-Basic Compiler (https://github.com/mougino/Basic-compiler/tree/master).

### Special thanks to the creators and uploaders of these assets:

Background Music - [https://commons.wikimedia.org/wiki/File:Winter_Wonderland.mid](url)

Static - [https://commons.wikimedia.org/wiki/File:Random_static.gif](url)

Testcard - [https://commons.wikimedia.org/wiki/File:Wiki-errorbg.png](url)

Android Gingerbread Logo - [https://commons.wikimedia.org/wiki/File:Android_Gingerbread.webp](url)

### Compilation Notes (WIP)

-audio doesn't work and causes program to fail in newer compilers. v1942 worked for me



full disclosure- The html parts of this app were partly made from examples written by Bing's AI.