REM Glomblin, a Glomble app for Android

REM Github.com/fastandphinneas/Glomble-Android-App
REM Copyright (c) 2025 fastandphinneas (github.com/fastandphinneas, glomble.com/profiles/CkVAV0nvyWEX)

HTML.OPEN
HTML.LOAD.URL "intro.html"
PAUSE 750
HTML.LOAD.URL "intro2.html"
TONE 1000, 750, 750
PAUSE 750
start:
HTML.LOAD.URL "https://glomble.com/"
PAUSE 2000
AUDIO.LOAD b, "music.mid"
AUDIO.PLAY b
AUDIO.LOOP
p=1
dlcheck:
dl$ = ""
DO
 HTML.GET.DATALINK dl$
 PAUSE 300
 IF dl$ <> "" THEN
  LINK$=MID$(dl$, 5)
  id$=MID$(LINK$, 27)
  ! check type of link
  IF IS_IN("create", LINK$) > 0 THEN
   AUDIO.PAUSE
   POPUP "Not supported in app, trying website..."
   BROWSE LINK$
   PAUSE 5000
   END
  ENDIF
  IF IS_IN("video", LINK$) > 0 THEN
   HTML.LOAD.URL LINK$
   AUDIO.PAUSE
   p=0
   GOTO dlcheck
  ENDIF
  IF IS_IN("glomble.com", LINK$) > 0 THEN
   HTML.LOAD.URL LINK$
   IF p=0 THEN
    AUDIO.PLAY b
    p=1
   ENDIF
  ENDIF
  IF IS_IN("glomble.com", LINK$) < 1 THEN BROWSE LINK$
 ENDIF
 PAUSE 1000
UNTIL 0
ENDIF
ONERROR:
GOTO start
! Back Key throws an error because of some of the above code. This works as a temporary fix, but could be useful to keep
